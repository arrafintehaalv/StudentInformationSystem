#include<stdio.h>
#include "package.h"
void load(struct std_detail *detail){
    FILE *fp = fopen("info","r");
    fread(detail,sizeof(struct std_detail),1,fp);
}
void save(struct std_detail *detail){
    FILE *fp = fopen("info","w");
    fwrite(detail,sizeof(struct std_detail),1,fp);
}
int getPulse(struct std_detail *detail){
    return detail->pulse;
}
float getBalance(struct std_detail *detail){
    return detail->balance;
}
