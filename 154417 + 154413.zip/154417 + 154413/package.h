#ifndef __PACKAGE_HEADER_
#define __PACKAGE_HEADER_


struct std_detail{
    int pulse;
    float balance;
};
void load(struct std_detail *detail);
void save(struct std_detail *detail);
int getPulse(struct std_detail *detail);
float getBalance(struct std_detail *detail);


#endif
