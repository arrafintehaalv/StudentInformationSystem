#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void delay(double sec);
struct info
{
    char name[25];
    char f_name[25];
    char f_contact[15];
    char m_name[25];
    char m_contact[15];
    char email[40];
    char house[100];
    char dob[20];
    char contact[15];
    char id[10];
    char pass[15];
    char ca[100];
    char cr1[100];
    char cr2[100];
    char blood[5];
    char session[10];
    char dept[50];
    char semester[5];
};
struct info newnode[1000];

int main()
{
    int choice,i=0,j,flag=0,c=0,k,l;
    double cgpa;
    char x;
    char name1[100],id1[10],pass1[15],contact1[15],hit,ca1[100],cr3[100];

    while(1)
    {

        //co:
        printf("\n\n\n\n\n\n\n\n\n\n\t\t\t\t!WELCOME!");
        delay(1);
        system("cls");
        printf("\n\n\n\n\n\n\n\n\n\t\t\t\t!!WELCOME!!");
        delay(0.1);
        system("cls");
        printf("\n\n\n\n\n\n\n\n\t\t\t\t!!WELCOME!!");
        delay(0.1);
        system("cls");
        printf("\n\n\n\n\n\n\n\n\n\n\n\t\t\t\t!!!WELCOME!!!");
        delay(0.1);
        system("cls");

        printf("\n\n\n\n\n\n\n\n\n\n\n\n\t\t\t\t!!!WELCOME!!!");
        delay(0.1);
        system("cls");
        printf("\n\n\n\n\n\n\n\n\n\n\t\t\t\t!!!!WELCOME!!!!");
        delay(1);
        system("cls");

        printf("\t\t\t\tWELCOME TO IUT(OIC) WEBSITE\n\t\t\t\tESTABLISHED IN 1981\n\t\tA SUBSIDIARY ORGAN OF ORGANISATION OF ISLAMIC CO-OPERATION\n");
        printf("________________________________________________________________________________");

        flag=0;
        printf("\n\n\n\n\t\t\t\t1. REGISTRATION\n\n\t\t\t\t2. LOGIN SECURITY\n\n\t\t\t\t3. APPLYING FOR SCHOLARSHIP\n\n\t\t\t\t4. COURSE REGISTRATION\n\n\t\t\t\t5. CO-CURRICULAR ACTIVITIES\n\n\t\t\t\t0. QUIT\n\n");
        printf("\n\t\t\t\tENTER YOUR CHOICE: ");

        scanf("%d",&choice);

        if(choice==0)
        {
            system("cls");
            printf("\n\n\n\n\n\n\n\n\n\n\t\t\tTHANK YOU FOR VISITING US !!!!!\n\n");
            delay(3);
            system("cls");
            break;
        }

        else if(choice==1)
        {
            system("cls");
            printf("\t\t\t\t\tREGISTRATION\n");
            printf("________________________________________________________________________________\n");
            printf("\t\tENTER YOUR NAME: ");
            getchar();
            gets(name1);
            printf("\n");
            strcpy(newnode[i].name,name1);

            printf("\t\tENTER YOUR DEPARTMENT: ");
            gets(name1);
            printf("\n");
            strcpy(newnode[i].dept,name1);

            printf("\t\tENTER YOUR ACADEMIC SESSION: ");
            gets(name1);
            printf("\n");
            strcpy(newnode[i].session,name1);

            printf("\t\tENTER YOUR CURRENT SEMESTER: ");
            gets(name1);
            printf("\n");
            strcpy(newnode[i].semester,name1);
            printf("\t\tENTER YOUR FATHER'S NAME: ");
            gets(name1);
            printf("\n");
            strcpy(newnode[i].f_name,name1);
            printf("\t\tENTER YOUR FATHER'S CONTACT NUMBER: ");
            gets(name1);
            printf("\n");
            strcpy(newnode[i].f_contact,name1);
            printf("\t\tENTER YOUR MOTHER'S NAME: ");
            gets(name1);
            printf("\n");
            strcpy(newnode[i].m_name,name1);
            printf("\t\tENTER YOUR MOTHER'S CONTACT: ");
            gets(name1);
            printf("\n");
            strcpy(newnode[i].m_contact,name1);
            printf("\t\tENTER YOUR EMAIL: ");
            gets(name1);
            printf("\n");
            strcpy(newnode[i].email,name1);
            printf("\t\tENTER YOUR HOUSE NO: ");
            gets(name1);
            printf("\n");
            strcpy(newnode[i].house,name1);

            printf("\t\tENTER YOUR ID: ");
            gets(name1);
            printf("\n");
            strcpy(newnode[i].id,name1);
            printf("\t\tENTER YOUR PASSWORD: ");
            gets(name1);
            printf("\n");
            strcpy(newnode[i].pass,name1);
            printf("\t\tENTER YOUR DATE OF BIRTH: ");
            gets(name1);
            printf("\n");
            strcpy(newnode[i].dob,name1);
            printf("\t\tENTER YOUR CONTACT NUMBER: ");
            gets(name1);
            printf("\n");
            strcpy(newnode[i].contact,name1);
            printf("\t\tENTER YOUR BLOOD GROUP: ");
            gets(name1);
            printf("\n");
            strcpy(newnode[i].blood,name1);
            system("cls");
            printf("\n\n\n\n\n\n\n\n\n\n\t\t\t\tWAIT FOR A FEW SECONDS...\n");
            delay(3);
            system("cls");
            printf("\n\n\n\n\n\n\n\n\n\n\t\t\t\tREGISTRATION COMPLETED\n");
            delay(3);
            choice=2;
            i++;
            system("cls");
        }

        else if(choice==3)
        {
            system("cls");
            printf("\t\t\t\tAPPLYING FOR SCHOLARSHIP\n");
            printf("________________________________________________________________________________\n");
            printf("\n\t\t\t\tENTER YOUR ID: ");
            getchar();
            gets(id1);
            printf("\n\t\t\t\tENTER YOUR PASSWORD: ");
            gets(pass1);
            for(j=0;j<i;j++){
                if((strcmp(newnode[j].id,id1)==0) && (strcmp(newnode[j].pass,pass1)==0) && ((strcmp(newnode[j].semester,"7th")==0)||(strcmp(newnode[j].semester,"8th")==0)||(strcmp(newnode[j].semester,"7")==0)||(strcmp(newnode[j].semester,"8")==0))){
                    system("cls");
                    printf("\n\n\n\n\n\n\n\n\n\n\t\t\t\tENTER YOUR CGPA: ");
                    scanf("%lf",&cgpa);
                    system("cls");
                    if(cgpa<3.8)
                    {
                        printf("\n\n\n\n\n\n\n\n\n\n\t\tSORRY. YOU ARE NOT ELIGIBLE FOR SCHOLARSHIP\n\n");
                    }
                    else if(cgpa>=3.8&&cgpa<=4.0)
                    {
                        printf("\n\n\n\n\n\n\n\n\n\n\t\tCONGRATULATIONS. YOU GET THE SCHOLARSHIP!!!!\n\n");
                    }
                    printf("\t\t\t\tENTER (X) TO CONTINUE: ");
                }

                else
                {
                    system("cls");
                    printf("\n\n\n\n\n\n\n\n\n\n\t\tSORRY. YOU ARE NOT UNDER THIS APPLIANCE\n\n");
                    printf("\t\t\tENTER (X) TO CONTINUE: ");

                }
            }
            while(1)
            {
                scanf("%c",&x);
                if(x=='X'||x=='x') break;
            }
            system("cls");
        }
        else if(choice==4)
        {
            system("cls");
            printf("\t\t\t\tCOURSE REGISTRATION\n");
            printf("________________________________________________________________________________\n");
            printf("\n\t\tENTER YOUR ID: ");
            getchar();
            gets(id1);
            printf("\n\n\t\tENTER YOUR PASSWORD: ");
            gets(pass1);
            system("cls");
            printf("\t\t\t\tCOURSE REGISTRATION\n");
            printf("________________________________________________________________________________\n");
            for(j=0;j<i;j++)
            {
                if((strcmp(newnode[j].id,id1)==0) && (strcmp(newnode[j].pass,pass1)==0))
                {
                    printf("\n\t\tCOMPULSORY SUBJECTS: ");

                    gets(cr3);
                    strcpy(newnode[j].cr1,cr3);

                    printf("\n\t\tELECTIVE SUBJECTS: ");

                    gets(cr3);
                    strcpy(newnode[j].cr2,cr3);

                    printf("\n\n\tCOMPULSORY AND ELECTIVE SUBJECTS ARE ADDED IN YOUR PROFILE\n");
                    delay(3);
                    system("cls");
                }
            }
        }
        else if(choice==5)
        {
            system("cls");
            printf("\t\t\t\tCO-CURRICULAR ACTIVITIES\n");
            printf("________________________________________________________________________________\n");
            printf("\n\t\tENTER YOUR ID: ");
            getchar();
            gets(id1);
            printf("\n\n\t\tENTER YOUR PASSWORD: ");

            gets(pass1);
            system("cls");
            for(j=0;j<i;j++)
            {
                if((strcmp(newnode[j].id,id1)==0) && (strcmp(newnode[j].pass,pass1)==0))
                {
                    printf("\n\n\t\tENTER YOUR NON-ACADEMIC ACTIVITIES: ");

                    gets(ca1);
                    strcpy(newnode[j].ca,ca1);
                    printf("\n\n\t\tNON-ACADEMIC ACTIVITIES ARE ADDED IN YOUR PROFILE");
                    delay(3);
                    system("cls");

                }
            }

        }

        else if(choice==2)
        {
            system("cls");
            printf("\t\t\t\t\tLOGIN SECURITY\n");
            printf("________________________________________________________________________________\n");
            printf("\n\t\t\t\tENTER YOUR ID: ");
            getchar();
            gets(id1);
            printf("\n\t\t\t\tENTER YOUR PASSWORD: ");
            gets(pass1);
            for(j=0;j<i;j++)
            {
                if((strcmp(newnode[j].id,id1)==0) && (strcmp(newnode[j].pass,pass1)==0))
                {
                     printf("\n\t\t\t\tLOGIN SUCCESSFULLY\n");
                     delay(3);
                     system("cls");

                     flag=1;
                     break;
                }
            }
            if(flag==1)
            {
                printf("\n\n\t\t\t\t\tPROFILE\n");
                printf("________________________________________________________________________________\n");
                printf("\n\t\tNAME: ");
                puts(newnode[j].name);
                printf("\n\t\tDEPARTMENT: ");
                puts(newnode[j].dept);
                printf("\n\t\tACADEMIC SESSION: ");
                puts(newnode[j].session);
                printf("\n\t\tSEMESTER: ");
                puts(newnode[j].semester);
                printf("\n\t\tFATHER'S NAME: ");
                puts(newnode[j].f_name);
                printf("\n\t\tFATHER'S CONTACT NUMBER: ");
                puts(newnode[j].f_contact);
                printf("\n\t\tMOTHER'S NAME: ");
                puts(newnode[j].m_name);
                printf("\n\t\tMOTHER'S CONTACT NUMBER: ");
                puts(newnode[j].contact);
                printf("\n\t\tEMAIL ID: ");
                puts(newnode[j].email);
                printf("\n\t\tHOUSE NO: ");
                puts(newnode[j].house);

                printf("\n\t\tID: ");
                puts(newnode[j].id);
                printf("\n\t\tPASSWORD: ");
                puts(newnode[j].pass);
                printf("\n\t\tDATE OF BIRTH: ");
                puts(newnode[j].dob);
                printf("\n\t\tBLOOD GROUP: ");
                puts(newnode[j].blood);

                printf("\n\t\tCONTACT NUMBER: ");
                puts(newnode[j].contact);
                printf("\n\t\tCO-CURRICULAR ACTIVITIES: ");
                puts(newnode[j].ca);
                printf("\n\t\tCOURSE SUBJECTS: ");

                printf("\n\n\t\tCOMPULSORY: ");
                puts(newnode[j].cr1);

                printf("\n\t\tELECTIVE: ");
                puts(newnode[j].cr2);

                printf("\n\n");
                printf("\t\t\tPRESS (Y) TO SIGN OUT AFTER EDITING PROFILE\n\n\t\t\tPRESS (N) TO SIGN OUT\n\n");
                scanf("%c",&hit);
                if(hit=='y'||hit=='Y')
                {
                    system("cls");
                    printf("\n\n\t\t\t\t\tEDIT PROFILE\n\n");
                    printf("\t\tENTER YOUR NAME: ");
                    getchar();
                    gets(name1);
                    printf("\n");
                    strcpy(newnode[j].name,name1);

                    printf("\t\tENTER YOUR PASSWORD: ");
                    gets(name1);
                    printf("\n");
                    strcpy(newnode[j].pass,name1);

                    printf("\t\tENTER YOUR CONTACT NUMBER: ");
                    gets(name1);
                    printf("\n");
                    strcpy(newnode[j].contact,name1);
                    printf("\t\tENTER YOUR BLOOD GROUP: ");
                    gets(name1);
                    printf("\n");
                    strcpy(newnode[j].blood,name1);
                    printf("\t\tENTER YOUR FATHER'S NAME: ");
                    gets(name1);
                    printf("\n");
                    strcpy(newnode[j].f_name,name1);
                    printf("\t\tENTER YOUR FATHER'S CONTACT NUMBER: ");
                    gets(name1);
                    printf("\n");
                    strcpy(newnode[j].f_contact,name1);
                    printf("\t\tENTER YOUR MOTHER'S NAME: ");
                    gets(name1);
                    printf("\n");
                    strcpy(newnode[j].m_name,name1);
                    printf("\t\tENTER YOUR MOTHER'S CONTACT NUMBER: ");
                    gets(name1);
                    printf("\n");
                    strcpy(newnode[j].m_contact,name1);
                    printf("\t\tENTER YOUR EMAIL ID: ");
                    gets(name1);
                    printf("\n");
                    strcpy(newnode[j].email,name1);
                    printf("\t\tENTER YOUR HOUSE NUMBER: ");
                    gets(name1);
                    printf("\n");
                    strcpy(newnode[j].house,name1);

                    system("cls");
                    printf("\n\n\n\n\n\n\n\n\n\n\t\t\t\tWAIT FOR A FEW SECONDS....");
                    delay(3);
                    system("cls");
                    printf("\n\n\n\n\n\n\n\n\n\n\t\t\t\tPROFILE CHANGED SUCCESSFULLY");
                    delay(3);
                    system("cls");
                    printf("\n\n\n\n\n\n\n\n\n\n\t\t\t\tSIGNING OUT AUTOMATICALLY... ");
                    delay(3);
                    system("cls");


                }
                else if(hit=='n'||hit=='N')
                {
                    system("cls");
                    printf("\n\n\n\n\n\n\n\n\n\n\t\t\t\tWAIT FOR A FEW SECONDS...");
                    delay(3);
                    system("cls");
                    printf("\n\n\n\n\n\n\n\n\n\n\t\t\t\tSIGN OUT SUCCESSFULLY");
                    delay(3);

                }

                    system("cls");
            }

            if(flag==0)
            {
                c++;
                printf("\n\t\t\t\tINCORRECT INFORMATION\n\n");

                delay(3);
                system("cls");
            }
            if(c==5) {c=0; printf("\t\t\t\tINCORRECT INFORMATION\n\n\t\t\t\tWAIT FOR 60 SECONDS\n"); delay(60); system("cls");}

        }

    }

}

void delay(double sec){
    clock_t start,current;
    start = clock();
    current = clock();
    while((double)(current-start)/CLOCKS_PER_SEC < sec)
        current = clock();
}

